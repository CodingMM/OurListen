//
//  UIView+trim.h
//  ProjectDemo
//
//  Created by Elean on 15/11/22.
//  Copyright (c) 2015年 Elean. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NSString(category)
//去除空格
- (NSString*)trim;

@end


//
//  ELNLabel.h
//  ScannerDemo
//
//  Created by Elean on 15/12/8.
//  Copyright © 2015年 Elean. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>
@interface ELNLabel : UILabel
@property (nonatomic,copy) NSString * textStr;
@property (nonatomic,copy) UIColor * color;

@end

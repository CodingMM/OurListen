//
//  ScannerDetailController.h
//  ScannerDemo
//
//  Created by Elean on 15/12/8.
//  Copyright © 2015年 Elean. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScannerDetailController : UIViewController

@property (nonatomic,copy) NSString * scannerValueStr;

@end

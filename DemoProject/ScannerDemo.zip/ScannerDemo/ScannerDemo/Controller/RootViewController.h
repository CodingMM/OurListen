//
//  RootViewController.h
//  ScannerDemo
//
//  Created by Elean on 15/12/8.
//  Copyright (c) 2015年 Elean. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController

@end
